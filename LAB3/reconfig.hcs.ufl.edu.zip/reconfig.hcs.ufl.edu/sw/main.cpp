// Greg Stitt
// University of Florida
// main.cpp
//

#include <iostream>
#include <cstdlib>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <vector>

#include "Board.h"

using namespace std;

enum mmapAddr {
  GO_ADDR=0, N_ADDR, RESULT_ADDR, DONE_ADDR
};
int fib(int n)
{
int i=3;
int a=1;
int b=1;
int temp;
while(i<=n)
{
temp=a+b;
a=b;
b=temp;
i++;
}
return b;
}

int main(int argc, char* argv[]) {
  
  if (argc != 2) {
    cerr << "Usage: " << argv[0] << " bitfile" << endl;
    return -1;
  }
  
  vector<float> clocks(Board::NUM_FPGA_CLOCKS);
  clocks[0] = 100.0;
  clocks[1] = 100.0;
  clocks[2] = 100.0;
  clocks[3] = 100.0;
  
  cout << "Programming FPGA...." << endl;

  // initialize board
  Board *board;
  try {
    board = new Board(argv[1], clocks);
  }
  catch(...) {
    exit(-1);
  }

  for(unsigned i=1;i<=30;i++)
  {
	int swResult = fib(i);
	unsigned n,go,result;
	n=i;
	//write n to n_addr
	board->write(&n,N_ADDR,1);
	for(int j=0;j<=1;j++)
	{
		go=j;
		assert(go==j);
		board->write(&go,GO_ADDR,1);
	}	
	
	//done =1 to get the result
	board->waitUntilNotZero(DONE_ADDR, 2.0);
	board->read(&result,RESULT_ADDR,1);
  printf("\n%d: HW = %d, SW = %d",i,result,swResult);
  }
	
  return 0;
}
