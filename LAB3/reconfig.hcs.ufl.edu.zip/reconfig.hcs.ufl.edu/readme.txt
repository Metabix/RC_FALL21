Name: Mohit Palliyil Sathyaseelan
Group: 45 
Group partner:Aaron Vuong

Tried implementing the extra credit part, not really sure. 