Name : mohit

part1 : added dual flip flops.

part2 : added registers as mentioned in the class; instanciated additional processes. 
  	took reference from https://www.edn.com/synchronizer-techniques-for-multi-clock-domain-socs-fpgas/

part3 : added fifo into the IP; then made changes to the port map.